﻿Option Strict On
Imports System.IO
Public Class frmTextEditor

    ' Subroutine for opening files
    Private Sub mnuOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click

        Dim openFile As New OpenFileDialog()

        openFile.CheckFileExists = True
        openFile.DefaultExt = "txt"
        openFile.InitialDirectory = "C:\"
        openFile.Multiselect = False

        If openFile.ShowDialog = DialogResult.OK Then
            Try
                Dim reader As New StreamReader(openFile.FileName)
                tbInput.Text = reader.ReadToEnd
                Me.Text = openFile.FileName
                reader.Close()
            Catch ex As Exception
                Throw New ApplicationException(ex.ToString)
            End Try
        End If

    End Sub

    ' Subroutine for saving file
    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click

        Dim saveFile As New SaveFileDialog()
        Dim alreadySavedFile As String = ""

        saveFile.Filter = "TXT Files (*.txt*)|*.txt"

        If alreadySavedFile = "" Then

            saveFile.ShowDialog()
            Me.Text = saveFile.FileName
            alreadySavedFile = saveFile.FileName

        Else

            My.Computer.FileSystem.WriteAllText(saveFile.FileName, tbInput.Text, False)
            Me.Text = saveFile.FileName
            alreadySavedFile = saveFile.FileName

        End If

    End Sub

    ' Subroutine for save as file
    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click

        Dim saveFile As New SaveFileDialog()

        saveFile.ShowDialog()

        My.Computer.FileSystem.WriteAllText(saveFile.FileName, tbInput.Text, False)

    End Sub

    ' Subroutine for exiting program
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Application.Exit()
    End Sub

    ' Subroutine for copying text
    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click
        tbInput.Copy()
    End Sub

    ' Subroutine for cutting text
    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        tbInput.Cut()
    End Sub

    ' Subroutine for pasting text
    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        tbInput.Paste()
    End Sub

End Class